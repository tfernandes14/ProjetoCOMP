// jucompiler -e1 < errors.java
// the standard Java compiler also shows these lexical errors
""                    // the empty string
"\\"                    // the empty string
"\""                  // a string containing " alone
"This is a string"    // a string containing 16 characters
"This is a " +        // actually a string-valued constant expression,
    "two-line strin\g"    // formed from two string literals
class Small #
	public static void main(String[] args) {
	}
#

"Hello /\\\\**/ boyyyy"

vari.able
02
1.e0_0
"\
"\\"
"hey\

"\\"
asd3.3
// Mooshak  Spamar mais deste genero
a-1.0
e-1

1.E+09
/*printf is used to print a message \*
   printf("Hello world");

   return 0;
