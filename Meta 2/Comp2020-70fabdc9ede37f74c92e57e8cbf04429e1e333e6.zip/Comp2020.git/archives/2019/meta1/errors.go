// ./gocompiler < errors.go
// the standard Go compiler also shows these lexical errors

package main

func main() $
  var $ int
$
