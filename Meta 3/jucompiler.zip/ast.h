#include "symbol_table.h"

struct node *create_node(char *type, char* value);
struct node *add_child(struct node *dad, struct node *child);
struct node *add_bro(struct node * s1, struct node * s2);
void print_tree(struct node *head, int depth);